import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Stack; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Pendula extends PApplet {



Round round;
int score = 0;
int highScore = 0;
int backFill = color(255, 255, 255, 0);
int backAlpha = 0;

public void setup() {
  

  round = createRound();
}

public void draw() {
  round.step();
  round.display();

  fill(red(backFill), green(backFill), blue(backFill), backAlpha);
  backAlpha -= 3;
  rect(0, 0, width, height);

  if (round.isOver()) {
    if(score > highScore) highScore = score;
    if (round.hasWon()) {
      backFill = color(0, 255, 0);
      int prevScore = score;
      score += 2 * 5 - round.parent.getTotalRevolutions(); // 5 -> radii.length
      if(score < prevScore) score = prevScore;
    } else {
      backFill = color(255, 0, 0);
      score = 0;
    }
    round = createRound();
    backAlpha = 255;
  }

  fill(255);
  textSize(35);
  text("Score: " + score, 10, 40);
  text("High Score: " + highScore, 10, 70);
}

public void keyPressed() {
  round.handleKey(key);
}

public void mouseClicked() {
  round.handleKey(' ');
}

public Round createRound() {
  Goal goal = new Goal(PVector.random2D().mult(random(30, 375)).add(new PVector(width / 2, height / 2)), 6.25f);
  float[] radii = {200, 100, 50, 25, 12.5f};

  return new Round(goal, radii, false);
}
public class CircleSeries {
  private static final float R_VEL = 0.05f;
  private static final boolean DRAW_CIRCLES = true;
  private PVector pos;
  private PVector dir;
  private boolean stopped;
  private float madeActiveTheta;
  private int revolutions;
  private CircleSeries child;

  public CircleSeries(Stack<CircleSeries> children) {
    CircleSeries me = children.pop();
    pos = me.pos;
    dir = me.dir;
    stopped = false;
    madeActiveTheta = 3 * PI;
    revolutions = 0;

    if (children.isEmpty()) {
      child = null;
    } else {
      child = new CircleSeries(children);
    }
  }

  public CircleSeries(PVector pos, float radius) {
    this.pos = pos;
    this.dir = new PVector(0, -radius);
  }

  public PVector getEndPoint() {
    if (child == null) {
      return pos.copy().add(dir);
    } else {
      return child.getEndPoint();
    }
  }

  public CircleSeries getFurthest() {
    if (child == null) { 
      return this;
    } else {
      return child.getFurthest();
    }
  }

  public boolean isStopped() {
    return stopped;
  }

  public PVector getPos() {
    return pos.copy();
  }

  public CircleSeries getActive() {
    return getActive(true);
  }

  public CircleSeries getActive(boolean parentStopped) {
    if (parentStopped && !stopped) {
      return this;
    } else {
      if (child == null) return child;
      return child.getActive(stopped);
    }
  }

  public float getUnfrozenLength() {
    if (child == null) {
      return dir.mag();
    } else if (stopped) {
      return child.getUnfrozenLength();
    } else {
      return dir.mag() + child.getUnfrozenLength();
    }
  }
  
  public int getTotalRevolutions(){
    if(child == null){
      return revolutions;
    }
    else{
      return revolutions + child.getTotalRevolutions();
    }
  }

  public void freezeNext() {
    if (stopped) { 
      child.freezeNext();
    } else {
      stopped = true;
      if (child != null)
        makeActiveTheta();
    }
  }
  
  public void makeActiveTheta(){
    child.madeActiveTheta = child.dir.heading();
  }

  public void step() {
    if (!stopped && dir.heading() < madeActiveTheta && dir.heading() + R_VEL >= madeActiveTheta) { 
      madeActiveTheta = dir.heading();
      revolutions++;
    }

    if (!stopped) {
      dir.rotate(R_VEL);
    }

    if (child != null) {
      child.pos = pos.copy().add(dir);   
      child.step();
    }
  }

  public void dispCircles() {
    if (DRAW_CIRCLES) {
      noFill();
      stroke(0, 0, 180);
      circle(pos.x, pos.y, dir.mag() * 2);
      if (madeActiveTheta <= TWO_PI) {
        PVector activeThetaPoint = PVector.fromAngle(madeActiveTheta).mult(dir.mag()).add(pos);
        line(pos.x, pos.y, activeThetaPoint.x, activeThetaPoint.y);
      }
    }

    if (child != null) {
      child.dispCircles();
    }
  }

  public void display() {
    display(true);
  }

  private void display(boolean parentStopped) {
    int col = color(255);
    if (stopped) col = color(130);
    else if (parentStopped && !stopped) col = color(0, 255, 0);

    if (child != null) {
      child.display(stopped);
    }

    fill(col);
    stroke(col);

    PVector endPos = pos.copy().add(dir);
    line(pos.x, pos.y, endPos.x, endPos.y);
    circle(endPos.x, endPos.y, dir.mag() / 10);
  }
}
public class Goal{
  private PVector pos;
  private float radius;
  
  public Goal(PVector pos, float radius){
    this.pos = pos.copy();
    this.radius = radius;
  }
  
  public PVector getPos(){
    return pos.copy();
  }
  
  public float getRadius(){
    return radius;
  }
  
  public boolean colliding(PVector point){
    return dist(point.x, point.y, pos.x, pos.y) <= radius;
  }
  
  public void display(){
    noStroke();
    fill(255, 0, 0);
    circle(pos.x, pos.y, radius * 2);
  }
}
public class Round {
  private CircleSeries parent;
  private Goal goal;
  private boolean playing;
  private boolean won;
  private boolean over;
  private boolean playOutImpossible;
  private float scaleFactor;
  private float targetScaleFactor;

  public Round(Goal goal, float[] radii, boolean playOutImpossible) {
    Stack<CircleSeries> parentStack = new Stack<CircleSeries>();

    for (int i = radii.length - 1; i >= 1; i--) {
      parentStack.push(new CircleSeries(null, radii[i]));
    }
    parentStack.push(new CircleSeries(new PVector(width / 2, height / 2), radii[0]));

    parent = new CircleSeries(parentStack);

    parent.step();
    parent.makeActiveTheta();

    this.goal = goal;
    playing = false;
    won = false;
    over = false;
    this.playOutImpossible = playOutImpossible;
    scaleFactor = 1;
    targetScaleFactor = 1;
  }

  public boolean isOver() {
    return over;
  }

  public boolean hasWon() {
    return won;
  }

  public void handleKey(char k) {
    if (k == ' ') { 
      if (playing) {
        parent.freezeNext();
        targetScaleFactor++;
      } else {
        playing = true;
      }
    }
  }

  public void step() {
    float error = targetScaleFactor - scaleFactor;
    scaleFactor += error * 0.05f;

    if (playing) {
      parent.step();
    }

    if (parent.getFurthest().isStopped()) {
      won = goal.colliding(parent.getEndPoint());
      over = true;
      playing = false;
    }

    if (!playOutImpossible && playing && parent.getActive().getPos().sub(goal.getPos()).mag() > parent.getUnfrozenLength() + goal.getRadius()) {
      won = false;
      over = true;
      playing = false;
    }
  }

  public void display() {
    background(0);

    pushMatrix();
    translate(goal.getPos().x, goal.getPos().y);
    scale(scaleFactor);
    translate(-goal.getPos().x, -goal.getPos().y);

    parent.dispCircles();
    goal.display();
    parent.display();

    stroke(130);
    fill(130);
    circle(width / 2, height / 2, 30);

    popMatrix();
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Pendula" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
